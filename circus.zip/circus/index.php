<?php
require_once 'config/db.php';

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_ticket'])) {
    $show_id = intval($_POST['show_id']);
    $customer_name = htmlspecialchars($_POST['customer_name']);
    $seats = intval($_POST['seats']);

    if ($show_id > 0 && !empty($customer_name) && $seats > 0) {
        $stmt = $conn->prepare("SELECT price FROM shows WHERE id = ?");
        $stmt->bind_param("i", $show_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $show = $res->fetch_assoc();
            $total_price = $show['price'] * $seats;
            $ticket_unique_id = 'TIX-' . strtoupper(substr(uniqid(), -6)) . rand(10, 99);

            $insert = $conn->prepare("INSERT INTO tickets (ticket_unique_id, show_id, customer_name, seats, total_price) VALUES (?, ?, ?, ?, ?)");
            $insert->bind_param("sisid", $ticket_unique_id, $show_id, $customer_name, $seats, $total_price);
            if ($insert->execute()) {
                $success_msg = "Booking successful! Your Ticket ID is: <strong>$ticket_unique_id</strong>. Total Price: ₹" . number_format($total_price, 2);
            }
            else {
                $error_msg = "Error booking ticket. Please try again.";
            }
            $insert->close();
        }
        else {
            $error_msg = "Invalid show selected.";
        }
        $stmt->close();
    }
    else {
        $error_msg = "Please fill in all fields correctly.";
    }
}

// Fetch Upcoming Shows
$shows_query = $conn->query("SELECT * FROM shows WHERE show_date >= CURDATE() ORDER BY show_date ASC");
$upcoming_shows = [];
if ($shows_query) {
    while ($row = $shows_query->fetch_assoc()) {
        $upcoming_shows[] = $row;
    }
}

// Fetch featured performers
$performers_query = $conn->query("SELECT * FROM performers ORDER BY RAND() LIMIT 4");
// Fetch featured animals
$animals_query = $conn->query("SELECT * FROM animals ORDER BY RAND() LIMIT 4");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Great Indian Circus - Experience the Magic</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            /* Vibrant Indian Colors */
            --brand-gold: #FF9933; /* Saffron/Gold */
            --brand-red: #8B181B; /* Deep Indian Red */
            --brand-green: #138808; /* Indian Flag Green */
            --theme-bg: #FFFBF0; /* Warm off-white */
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--theme-bg); color: #2C1810; }
        [data-theme="dark"] body { background-color: #111827; color: #F9FAFB; }
        
        h1, h2, h3, .brand-font { font-family: 'Playfair Display', serif; }
        
        /* Interactive Nav */
        .public-nav { position: fixed; top: 0; width: 100%; z-index: 1000; background: rgba(255,251,240,0.95); backdrop-filter: blur(10px); transition: all 0.3s ease; border-bottom: 2px solid var(--brand-gold); }
        [data-theme="dark"] .public-nav { background: rgba(31,41,55,0.95); border-bottom: 2px solid var(--brand-red); }

        /* Full Screen Hero with Parallax effect */
        .hero-enhanced {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            background: url('https://images.unsplash.com/photo-1544078759-40461dc6fce7?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80') center/cover fixed; /* Indian Cultural Festival Vibe */
            color: white;
            text-align: center;
            padding: 5rem 1rem;
        }
        .hero-enhanced::before {
            content: ''; position: absolute; inset: 0;
            background: linear-gradient(to bottom, rgba(50,0,0,0.5), rgba(0,0,0,0.8));
            z-index: 1;
        }
        .hero-content { position: relative; z-index: 2; max-width: 900px; animation: fadeIn 2s ease; }
        .hero-content h1 { font-size: 5rem; margin-bottom: 1rem; letter-spacing: 2px; text-transform: uppercase; text-shadow: 2px 4px 10px rgba(0,0,0,0.8); color: var(--brand-gold); }
        .hero-content p { font-size: 1.5rem; margin-bottom: 2.5rem; font-weight: 400; text-shadow: 1px 2px 5px rgba(0,0,0,0.8); color: #fff; }
        
        .animated-btn {
            background-color: var(--brand-red);
            color: white; padding: 1rem 3rem; font-size: 1.5rem; font-weight: bold;
            border-radius: 5px; text-transform: uppercase; letter-spacing: 2px;
            transition: transform 0.3s, box-shadow 0.3s, background-color 0.3s;
            display: inline-block; box-shadow: 0 6px 20px rgba(139,24,27,0.6);
            border: 2px solid var(--brand-gold);
        }
        .animated-btn:hover {
            transform: translateY(-5px) scale(1.05); box-shadow: 0 10px 30px rgba(139,24,27,0.8);
            color: var(--brand-gold);
        }

        /* Section Layouts */
        .section-title { text-align: center; font-size: 3.5rem; margin-bottom: 3rem; color: var(--brand-red); position: relative; padding-bottom: 1rem; }
        .section-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 120px; height: 4px; background-color: var(--brand-gold); }
        [data-theme="dark"] .section-title { color: var(--brand-gold); }
        [data-theme="dark"] .section-title::after { background-color: var(--brand-red); }

        .about-section { padding: 6rem 5%; background-color: var(--theme-bg); border-bottom: 4px solid var(--brand-red); }
        [data-theme="dark"] .about-section { background-color: #1F2937; }
        .about-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; max-width: 1200px; margin: 0 auto; }
        .about-text p { font-size: 1.2rem; line-height: 1.8; margin-bottom: 1.5rem; color: #4B5563; }
        [data-theme="dark"] .about-text p { color: #D1D5DB; }
        .about-image { border-radius: 1rem; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.2); border: 3px solid var(--brand-gold); }
        .about-image img { width: 100%; height: auto; transform: scale(1); transition: transform 0.5s ease; }
        .about-image:hover img { transform: scale(1.05); }

        /* Performers & Animals Cards */
        .roster-section { padding: 6rem 5%; background-color: #FFF; background-image: url('https://www.transparenttextures.com/patterns/arabesque.png'); }
        [data-theme="dark"] .roster-section { background-color: #111827; background-blend-mode: multiply; }
        .roster-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; max-width: 1200px; margin: 0 auto; }
        .roster-card { 
            background: var(--card-bg); border-radius: 1rem; overflow: hidden; 
            box-shadow: 0 10px 20px rgba(0,0,0,0.1); transition: transform 0.4s ease;
            position: relative; border-bottom: 5px solid var(--brand-gold);
        }
        .roster-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.2); }
        .roster-image { height: 280px; background-color: #E5E7EB; position: relative; }
        .roster-image img { width: 100%; height: 100%; object-fit: cover; }
        .roster-info { padding: 1.5rem; text-align: center; }
        .roster-info h3 { font-size: 1.75rem; margin-bottom: 0.5rem; color: var(--text-color); font-family: 'Playfair Display', serif; }
        .roster-info p { color: var(--brand-red); font-weight: 600; font-size: 1.1rem; }
        [data-theme="dark"] .roster-info p { color: var(--brand-gold); }
        
        /* Book Tickets Section */
        .booking-section { padding: 6rem 5%; background-color: var(--theme-bg); border-top: 4px solid var(--brand-gold); }
        [data-theme="dark"] .booking-section { background-color: #1F2937; }
        .booking-container { max-width: 1200px; margin: 0 auto; background: #FFF; border-radius: 1.5rem; padding: 4rem; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.1); border: 2px solid rgba(255,153,51,0.3); }
        [data-theme="dark"] .booking-container { background: #111827; border-color: rgba(139,24,27,0.5); }
        .booking-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; }
        
        /* Shows Schedule List Styling */
        .show-list-item { 
            display: flex; justify-content: space-between; align-items: center; 
            padding: 1.5rem; border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: background-color 0.2s;
        }
        .show-list-item:hover { background-color: rgba(255,153,51,0.05); border-left: 4px solid var(--brand-gold); }
        [data-theme="dark"] .show-list-item { border-color: rgba(255,255,255,0.05); }
        [data-theme="dark"] .show-list-item:hover { background-color: rgba(255,255,255,0.02); }
        
        .footer-enhanced { background-color: var(--brand-red); color: #FFF; padding: 5rem 5% 2rem; text-align: center; border-top: 5px solid var(--brand-gold); background-image: url('https://www.transparenttextures.com/patterns/arabesque.png'); }
        .footer-logo { font-size: 2.5rem; color: var(--brand-gold); margin-bottom: 1rem; font-family: 'Playfair Display', serif; }
        .footer-enhanced p { max-width: 700px; margin: 0 auto 2rem; line-height: 1.8; font-size: 1.1rem; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        @media (max-width: 900px) {
            .about-grid, .booking-layout, .roster-grid { grid-template-columns: 1fr; }
            .hero-content h1 { font-size: 3.5rem; }
            .booking-container { padding: 2rem; }
        }
    </style>
</head>
<body>

    <nav class="public-nav">
        <div class="logo brand-font" style="font-size:1.8rem; color: var(--brand-red);">
            <i class="fas fa-campground"></i> Great Indian Circus
        </div>
        <div class="nav-links" style="display:flex; align-items:center; gap: 1.5rem;">
            <a href="#about" style="font-weight:600; text-transform:uppercase; font-size:0.9rem; color: var(--brand-red);">The Royal Heritage</a>
            <a href="#attractions" style="font-weight:600; text-transform:uppercase; font-size:0.9rem; color: var(--brand-red);">Kala & Attractions</a>
            <a href="#book-tickets" class="btn" style="background-color: var(--brand-gold); color: white; border-radius:5px; padding:0.5rem 1.25rem; font-weight:bold;">Book Tickets</a>
            <button id="theme-toggle" class="theme-switch" title="Toggle Dark Mode"></button>
            <a href="admin/login.php" style="color:var(--brand-red);" title="Admin Portal"><i class="fas fa-lock"></i></a>
        </div>
    </nav>

    <header class="hero-enhanced">
        <div class="hero-content">
            <h1>The Grandest Indian<br>Spectacle</h1>
            <p>Experience the majestic fusion of traditional Indian artistry, breathtaking acrobatics, and royal grandeur that will leave you spellbound.</p>
            <a href="#book-tickets" class="animated-btn">Secure Your Seats <i class="fas fa-ticket-alt" style="margin-left:0.5rem;"></i></a>
        </div>
    </header>

    <section id="about" class="about-section">
        <div class="about-grid">
            <div class="about-image">
                <img src="https://images.unsplash.com/photo-1542284241-158a7abaf69f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Indian Cultural Performance" onerror="this.src='https://images.unsplash.com/photo-1514222134-b57cbf8ce698?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'">
            </div>
            <div class="about-text">
                <h2 class="section-title" style="text-align: left; margin-bottom: 2rem;">A Royal Heritage of Wonder</h2>
                <p>Rooted deep in the vibrant culture and traditions of India, The Great Indian Circus brings together the most extraordinary talents from across the subcontinent under one magnificent colorful tent.</p>
                <p>Prepare to be transported to a realm where ancient street arts evolve into death-defying stunts, where the beats of the dhol sync with the heartbeats of the audience, and every magnificent moment is crafted to elicit pure amazement.</p>
                <div style="margin-top: 2rem; display: flex; gap: 2rem;">
                    <div>
                        <div style="font-size:3rem; font-weight:bold; color:var(--brand-red);">10L+</div>
                        <div style="text-transform:uppercase; font-size:0.9rem; color:#6B7280; font-weight:bold; letter-spacing:1px;">Delighted Guests</div>
                    </div>
                    <div>
                        <div style="font-size:3rem; font-weight:bold; color:var(--brand-red);">50+</div>
                        <div style="text-transform:uppercase; font-size:0.9rem; color:#6B7280; font-weight:bold; letter-spacing:1px;">Desi Master Acts</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="attractions" class="roster-section">
        <h2 class="section-title">Star Attractions Showcase</h2>
        
        <?php if ($performers_query && $performers_query->num_rows > 0): ?>
        <h3 class="brand-font" style="text-align:center; font-size:2.5rem; margin-bottom:2.5rem; color:var(--brand-red);">Master Performers</h3>
        <div class="roster-grid" style="margin-bottom: 5rem;">
            <?php while ($p = $performers_query->fetch_assoc()): ?>
            <div class="roster-card">
                <div class="roster-image">
                    <img src="https://source.unsplash.com/random/400x400/?india,traditional,dance,<?php echo urlencode($p['skill']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>">
                </div>
                <div class="roster-info">
                    <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                    <p><i class="fas fa-star" style="color:var(--brand-gold); margin-right:5px;"></i> <?php echo htmlspecialchars($p['skill']); ?></p>
                </div>
            </div>
            <?php
    endwhile; ?>
        </div>
        <?php
endif; ?>

        <?php if ($animals_query && $animals_query->num_rows > 0): ?>
        <h3 class="brand-font" style="text-align:center; font-size:2.5rem; margin-bottom:2.5rem; color:var(--brand-red);">Majestic Companions</h3>
        <div class="roster-grid">
            <?php while ($a = $animals_query->fetch_assoc()): ?>
            <div class="roster-card">
                <div class="roster-image">
                    <img src="https://source.unsplash.com/random/400x400/?india,animal,<?php echo urlencode($a['type']); ?>" alt="<?php echo htmlspecialchars($a['name']); ?>">
                </div>
                <div class="roster-info">
                    <h3><?php echo htmlspecialchars($a['name']); ?></h3>
                    <p><i class="fas fa-paw" style="color:var(--brand-red); margin-right:5px;"></i> <?php echo htmlspecialchars($a['type']); ?></p>
                </div>
            </div>
            <?php
    endwhile; ?>
        </div>
        <?php
endif; ?>
    </section>

    <section id="book-tickets" class="booking-section">
        <h2 class="section-title">Experience the Utsav Live</h2>
        <div class="booking-container">
            <?php if ($success_msg): ?>
                <div class="alert alert-success" style="font-size:1.1rem; padding:1.5rem; background-color:#E6FFFA; border-color:#38B2AC; color:#2C7A7B;"><i class="fas fa-check-circle" style="font-size:1.5rem; vertical-align:middle; margin-right:0.5rem;"></i> <?php echo $success_msg; ?></div>
            <?php
endif; ?>
            <?php if ($error_msg): ?>
                <div class="alert alert-danger" style="font-size:1.1rem; padding:1.5rem; background-color:#FFF5F5; border-color:#FEB2B2; color:#C53030;"><i class="fas fa-exclamation-circle" style="font-size:1.5rem; vertical-align:middle; margin-right:0.5rem;"></i> <?php echo $error_msg; ?></div>
            <?php
endif; ?>

            <div class="booking-layout">
                <!-- Upcoming Shows List -->
                <div>
                    <h3 class="brand-font" style="font-size:2rem; margin-bottom:1.5rem; color:var(--text-color);"><i class="far fa-calendar-check" style="color:var(--brand-gold); margin-right:0.5rem;"></i> Upcoming Utsav Dates</h3>
                    <div style="background:var(--card-bg); border-radius:1rem; overflow:hidden; border:1px solid rgba(0,0,0,0.1);">
                        <?php if (empty($upcoming_shows)): ?>
                            <div style="padding: 2rem; text-align:center; color:#6B7280;">No tour dates available right now.</div>
                        <?php
else: ?>
                            <?php foreach (array_slice($upcoming_shows, 0, 5) as $s): ?>
                            <div class="show-list-item">
                                <div>
                                    <div style="font-weight:bold; font-size:1.2rem; color:var(--text-color); margin-bottom:0.25rem;">
                                        <?php echo htmlspecialchars($s['name']); ?>
                                    </div>
                                    <div style="color:#6B7280; font-size:0.95rem;">
                                        <i class="fas fa-map-marker-alt" style="color:var(--brand-red);"></i> <?php echo htmlspecialchars($s['location']); ?> &nbsp; | &nbsp;
                                        <i class="far fa-clock" style="color:var(--brand-red);"></i> <?php echo date('M d, Y', strtotime($s['show_date'])); ?> @ <?php echo date('h:i A', strtotime($s['show_time'])); ?>
                                    </div>
                                </div>
                                <div style="font-weight:bold; color:var(--brand-gold); font-size:1.5rem;">
                                    ₹<?php echo number_format($s['price'], 2); ?>
                                </div>
                            </div>
                            <?php
    endforeach; ?>
                        <?php
endif; ?>
                    </div>
                </div>

                <!-- Booking Form -->
                <div>
                    <div class="card" style="margin-bottom:0; box-shadow:0 15px 35px rgba(0,0,0,0.05); border:none; background:var(--card-bg); border-top: 5px solid var(--brand-red);">
                        <div class="card-header" style="border-bottom:1px solid rgba(0,0,0,0.05); padding-bottom:1rem;">
                            <h3 style="margin: 0; font-family:'Inter', sans-serif; color:var(--text-color);"><i class="fas fa-ticket-alt text-danger" style="color:var(--brand-red);"></i> Reserve Your Entry</h3>
                        </div>
                        <form method="POST" action="#book-tickets" class="needs-validation" novalidate style="margin-top:1.5rem;">
                            <div class="form-group">
                                <label for="book_show_id" style="color:var(--text-color);">Select Performance</label>
                                <select name="show_id" id="book_show_id" class="form-control" style="height:3.5rem; font-size:1.1rem; border-color:rgba(0,0,0,0.1);" required>
                                    <option value="" data-price="0">-- Choose Date & Time --</option>
                                    <?php foreach ($upcoming_shows as $s): ?>
                                        <option value="<?php echo $s['id']; ?>" data-price="<?php echo $s['price']; ?>">
                                            <?php echo htmlspecialchars($s['name']); ?> - <?php echo date('M d', strtotime($s['show_date'])); ?> (₹<?php echo number_format($s['price'], 2); ?>)
                                        </option>
                                    <?php
endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group" style="margin-top:1.5rem;">
                                <label for="customer_name" style="color:var(--text-color);">Ticket Holder Name</label>
                                <input type="text" name="customer_name" id="customer_name" class="form-control" style="height:3.5rem; font-size:1.1rem; border-color:rgba(0,0,0,0.1);" required placeholder="e.g. Rahul Sharma">
                            </div>

                            <div class="form-group" style="margin-top:1.5rem;">
                                <label for="book_seats" style="color:var(--text-color);">Number of Passports</label>
                                <input type="number" name="seats" id="book_seats" class="form-control" style="height:3.5rem; font-size:1.1rem; border-color:rgba(0,0,0,0.1);" required min="1" max="10" placeholder="1">
                            </div>

                            <div class="form-group" style="margin-top:2rem; background:rgba(255,153,51,0.1); padding:1.5rem; border-radius:0.5rem; border-left:5px solid var(--brand-gold);">
                                <div class="flex-between" style="font-size: 1.5rem; font-weight: bold; color:var(--text-color);">
                                    <span>Total Value:</span>
                                    <span id="total_price_display" style="color: var(--brand-red);">₹0.00</span>
                                </div>
                            </div>

                            <button type="submit" name="book_ticket" class="btn w-100" style="background-color:var(--brand-red); color:white; font-size: 1.25rem; padding: 1.25rem; margin-top:1rem; text-transform:uppercase; letter-spacing:2px; border-radius:0.5rem; border:2px solid var(--brand-gold); font-weight:bold; box-shadow: 0 5px 15px rgba(139,24,27,0.3);">
                                Confirm Purchase <i class="fas fa-magic" style="margin-left:0.5rem;"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer-enhanced">
        <div class="footer-logo"><i class="fas fa-om" style="margin-right:0.5rem;"></i> Great Indian Circus</div>
        <p>Combining the mystical arts of ancient India with modern theatrical brilliance. Bringing wonder, astonishment, and pride to audiences around the globe since 1895. Join us under the grand royal tent for an unforgettable evening of pristine magic.</p>
        <div style="font-size: 2rem; color: var(--brand-gold); display:flex; justify-content:center; gap: 2rem; margin-bottom: 2.5rem;">
            <i class="fab fa-facebook hover-white" style="cursor:pointer;"></i>
            <i class="fab fa-twitter hover-white" style="cursor:pointer;"></i>
            <i class="fab fa-instagram hover-white" style="cursor:pointer;"></i>
            <i class="fab fa-youtube hover-white" style="cursor:pointer;"></i>
        </div>
        <div style="border-top:1px solid rgba(255,255,255,0.1); padding-top:2rem; font-size:0.95rem; color:rgba(255,255,255,0.7);">
            &copy; <?php echo date('Y'); ?> Great Indian Circus Management. Proudly Made in India. All Rights Reserved.
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
      // Enhance Navbar on Scroll - dark/light mode adaptable
      window.addEventListener('scroll', () => {
          const nav = document.querySelector('.public-nav');
          const isDark = document.body.getAttribute('data-theme') === 'dark';
          if (window.scrollY > 50) {
              nav.style.boxShadow = isDark ? '0 4px 20px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.05)';
              nav.style.padding = '0.5rem 5%';
          } else {
              nav.style.boxShadow = 'none';
              nav.style.padding = '1rem 5%';
          }
      });

      // Strict recalculation logic
      document.addEventListener('DOMContentLoaded', () => {
        const showSelect = document.getElementById('book_show_id');
        const seatsInput = document.getElementById('book_seats');
        const totalDisplay = document.getElementById('total_price_display');
        
        function calculateTotal() {
          if (showSelect && seatsInput && totalDisplay) {
            const selectedOption = showSelect.options[showSelect.selectedIndex];
            if (selectedOption && selectedOption.value !== "") {
              const price = parseFloat(selectedOption.getAttribute('data-price') || 0);
              const seats = parseInt(seatsInput.value || 0);
              const total = (price * seats).toFixed(2);
              totalDisplay.textContent = '₹' + total;
            } else {
              totalDisplay.textContent = '₹0.00';
            }
          }
        }

        if (showSelect) showSelect.addEventListener('change', calculateTotal);
        if (seatsInput) seatsInput.addEventListener('input', calculateTotal);
      });
    </script>
</body>
</html>

# Circus Management System - Setup Instructions

## Requirements
* XAMPP/WAMP or any standard Apache + MySQL platform
* PHP 7.4 or newer (supports PHP 8+)

## Installation Steps

1. **Move Folder**
   Place the entire `circus` folder inside your XAMPP `htdocs` directory (or WAMP `www` folder).
   * Example path: `C:\xampp\htdocs\circus\`

2. **Database Setup**
   * Start **Apache** and **MySQL** from your XAMPP Control Panel.
   * Go to `http://localhost/phpmyadmin` in your browser.
   * Create a new database named `circus_management`.
   * Click the **Import** tab at the top.
   * Click **Choose File** and select the `database.sql` file located in the root folder of this project.
   * Scroll down and click **Go** to import all tables.
   
   *(Note: Once the database structure exists, the system automatically checks for an admin user. If missing, it securely generates one for you using `config/db.php`).*

3. **Open the Application**
   * Open your web browser and navigate to: `http://localhost/circus/`
   * This is the "Public Facing" Ticket Booking page for your customers.

4. **Access the Admin Portal**
   * Click on "Admin Login" from the public site header or go to: `http://localhost/circus/admin/login.php`
   * **Default Username:** `admin`
   * **Default Password:** `admin123`

## Quick Troubleshooting
* **Image Uploads Not Working?**: Make sure the `uploads/` directory inside the project folder has write permissions.
* **Database Connection Error?**: Verify that your MySQL username is `root` and there is no password. If you have a different setup, edit lines `5-7` in `config/db.php`.

Enjoy managing your circus!

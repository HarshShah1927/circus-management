<?php
session_start();

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'circus_management';

// Connect to MySQL server first (without DB) to create DB if it doesn't exist
$server_conn = new mysqli($host, $user, $pass);
if ($server_conn->connect_error) {
    die("Connection failed: " . $server_conn->connect_error);
}

// Create database if it does not exist
$server_conn->query("CREATE DATABASE IF NOT EXISTS `$dbname`");
$server_conn->close();

// Now connect to the database
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Auto-seed admin user if user table is empty or missing admin
// Ensures the requirement "Default login: admin / admin123" is met on first run securely.
$check_admin = $conn->query("SELECT * FROM users WHERE username='admin'");
if ($check_admin) {
    if ($check_admin->num_rows == 0) {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES ('admin', ?)");
        $stmt->bind_param("s", $hash);
        $stmt->execute();
        $stmt->close();
    }
} else {
    // If table doesn't exist yet, we silently ignore here. 
    // They are supposed to import database.sql first.
}
?>

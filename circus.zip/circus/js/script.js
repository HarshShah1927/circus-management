document.addEventListener('DOMContentLoaded', () => {
  // Dark Mode Toggle
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.body.setAttribute('data-theme', 'dark');
      themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
      document.body.setAttribute('data-theme', 'light');
      themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    }

    themeToggle.addEventListener('click', () => {
      const currentTheme = document.body.getAttribute('data-theme');
      if (currentTheme === 'dark') {
        document.body.setAttribute('data-theme', 'light');
        localStorage.setItem('theme', 'light');
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
      } else {
        document.body.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
      }
      
      // Update charts if they exist
      if (typeof updateChartsTheme === 'function') {
        updateChartsTheme();
      }
    });
  }

  // Sidebar Toggle for Mobile
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const sidebar = document.querySelector('.sidebar');
  if (mobileMenuBtn && sidebar) {
    mobileMenuBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }

  // Search Filter for Tables
  const searchInput = document.getElementById('table-search');
  if (searchInput) {
    searchInput.addEventListener('keyup', function() {
      let filter = this.value.toLowerCase();
      let tableRows = document.querySelectorAll('tbody tr');
      
      tableRows.forEach(row => {
        let text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
      });
    });
  }

  // Ticket Pricing Calculator
  const showSelect = document.getElementById('book_show_id');
  const seatsInput = document.getElementById('book_seats');
  const totalDisplay = document.getElementById('total_price_display');
  
  function calculateTotal() {
    if (showSelect && seatsInput && totalDisplay) {
      const selectedOption = showSelect.options[showSelect.selectedIndex];
      if (selectedOption && selectedOption.value !== "") {
        const price = parseFloat(selectedOption.getAttribute('data-price') || 0);
        const seats = parseInt(seatsInput.value || 0);
        const total = (price * seats).toFixed(2);
        totalDisplay.textContent = '$' + total;
      } else {
        totalDisplay.textContent = '$0.00';
      }
    }
  }

  if (showSelect) showSelect.addEventListener('change', calculateTotal);
  if (seatsInput) seatsInput.addEventListener('input', calculateTotal);

});

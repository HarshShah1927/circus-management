<?php
session_start();
require_once '../config/db.php';

if (isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $user = $res->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit;
            }
            else {
                $error = "Invalid credentials!";
            }
        }
        else {
            $error = "Invalid credentials!";
        }
        $stmt->close();
    }
    else {
        $error = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Circus Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-user-shield"></i>
                <h2>Admin Login</h2>
                <p style="color: #6B7280; margin-top: 0.5rem;">Access the Circus Management System</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
            <?php
endif; ?>
            <div class="alert alert-success" style="font-size: 0.9rem;">
                <strong>Demo Access:</strong><br>
                Username: <code>admin</code><br>
                Password: <code>admin123</code>
            </div>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" class="form-control" required value="admin">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" class="form-control" required value="admin123">
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-3" style="padding: 0.75rem; font-size: 1.1rem;">
                    Sign In <i class="fas fa-sign-in-alt ml-2"></i>
                </button>
                <div style="text-align: center; margin-top: 1rem;">
                    <a href="../index.php" style="color: var(--primary); font-size: 0.9rem;"><i class="fas fa-arrow-left"></i> Back to Public Site</a>
                </div>
            </form>
        </div>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>

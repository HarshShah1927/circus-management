<?php
require_once '../config/db.php';
require_once 'includes/header.php';

$msg = '';
$edit_mode = false;
$edit_id = 0;
$show = ['name' => '', 'show_date' => '', 'show_time' => '', 'duration' => '', 'location' => '', 'price' => ''];
$assigned_performers = [];
$assigned_animals = [];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM show_assignments WHERE show_id=$id");
    $conn->query("DELETE FROM shows WHERE id=$id");
    header("Location: shows.php?msg=deleted");
    exit;
}
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted')
    $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Show canceled and removed successfully.</div>";

// Handle Add / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $date = $conn->real_escape_string($_POST['show_date']);
    $time = $conn->real_escape_string($_POST['show_time']);
    $duration = intval($_POST['duration']);
    $location = $conn->real_escape_string($_POST['location']);
    $price = floatval($_POST['price']);

    $performers = $_POST['performers'] ?? [];
    $animals = $_POST['animals'] ?? [];

    if (isset($_POST['id']) && $_POST['id'] > 0) {
        $id = intval($_POST['id']);
        $sql = "UPDATE shows SET name='$name', show_date='$date', show_time='$time', duration=$duration, location='$location', price=$price WHERE id=$id";
        if ($conn->query($sql)) {
            $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Show schedule updated successfully.</div>";
        }
    }
    else {
        $sql = "INSERT INTO shows (name, show_date, show_time, duration, location, price) VALUES ('$name', '$date', '$time', $duration, '$location', $price)";
        if ($conn->query($sql)) {
            $id = $conn->insert_id;
            $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Show scheduled successfully.</div>";
        }
    }

    // Manage Assignments if show id exists
    if (isset($id) && $id > 0) {
        $conn->query("DELETE FROM show_assignments WHERE show_id=$id");

        foreach ($performers as $pid) {
            $pid = intval($pid);
            if ($pid > 0)
                $conn->query("INSERT INTO show_assignments (show_id, entity_type, entity_id) VALUES ($id, 'performer', $pid)");
        }
        foreach ($animals as $aid) {
            $aid = intval($aid);
            if ($aid > 0)
                $conn->query("INSERT INTO show_assignments (show_id, entity_type, entity_id) VALUES ($id, 'animal', $aid)");
        }
    }
}

// Prepare Edit Mode Data
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $q = $conn->query("SELECT * FROM shows WHERE id=$edit_id");
    if ($q && $q->num_rows > 0)
        $show = $q->fetch_assoc();

    // Fetch assignments for multi-selects pre-population
    $pq = $conn->query("SELECT entity_id FROM show_assignments WHERE show_id=$edit_id AND entity_type='performer'");
    if ($pq) {
        while ($r = $pq->fetch_assoc())
            $assigned_performers[] = $r['entity_id'];
    }

    $aq = $conn->query("SELECT entity_id FROM show_assignments WHERE show_id=$edit_id AND entity_type='animal'");
    if ($aq) {
        while ($r = $aq->fetch_assoc())
            $assigned_animals[] = $r['entity_id'];
    }
}

$list = $conn->query("SELECT * FROM shows ORDER BY show_date DESC, show_time DESC");

// Fetch lists for multi-select
$perfList = $conn->query("SELECT id, name, skill FROM performers ORDER BY name ASC");
$animList = $conn->query("SELECT id, name, type FROM animals ORDER BY name ASC");
?>

<div class="flex-between mb-3">
    <h2><i class="fas fa-theater-masks"></i> Manage Shows</h2>
    <?php if ($edit_mode): ?>
        <a href="shows.php" class="btn btn-success"><i class="fas fa-plus"></i> Schedule New Show</a>
    <?php
endif; ?>
</div>

<?php echo $msg; ?>

<div class="card mb-4" style="border-top: 4px solid var(--secondary);">
    <div class="card-header">
        <h3 style="margin:0;"><i class="fas <?php echo $edit_mode ? 'fa-edit' : 'fa-calendar-plus'; ?>"></i> <?php echo $edit_mode ? 'Edit Show Configuration' : 'Schedule New Show'; ?></h3>
    </div>
    <form method="POST" action="shows.php" class="needs-validation" novalidate>
        <?php if ($edit_mode): ?>
            <input type="hidden" name="id" value="<?php echo $edit_id; ?>">
        <?php
endif; ?>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
            <div class="form-group">
                <label>Event Name</label>
                <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($show['name']); ?>" placeholder="e.g. Summer Spectacular">
            </div>
            <div class="form-group">
                <label>Show Date</label>
                <input type="date" name="show_date" class="form-control" required value="<?php echo htmlspecialchars($show['show_date']); ?>">
            </div>
            <div class="form-group">
                <label>Start Time</label>
                <input type="time" name="show_time" class="form-control" required value="<?php echo htmlspecialchars($show['show_time']); ?>">
            </div>
            <div class="form-group">
                <label>Duration (Minutes)</label>
                <input type="number" name="duration" class="form-control" required min="30" value="<?php echo htmlspecialchars($show['duration']); ?>">
            </div>
            <div class="form-group">
                <label>Location / Tent</label>
                <input type="text" name="location" class="form-control" required value="<?php echo htmlspecialchars($show['location']); ?>" placeholder="e.g. Main Tent">
            </div>
            <div class="form-group">
                <label>Ticket Price (₹)</label>
                <input type="number" step="0.01" name="price" class="form-control" required min="0" value="<?php echo htmlspecialchars($show['price']); ?>">
            </div>
        </div>

        <h4 class="mt-4 mb-3" style="border-bottom:1px solid var(--border-color); padding-bottom:0.5rem; color:var(--primary);"><i class="fas fa-magic"></i> Roster Assignments</h4>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
            <div class="form-group">
                <label>Assign Performers</label>
                <select name="performers[]" class="form-control" multiple size="6" style="height:auto; min-height:120px; font-size:0.95rem;">
                    <?php if ($perfList && $perfList->num_rows > 0):
    while ($p = $perfList->fetch_assoc()): ?>
                        <option value="<?php echo $p['id']; ?>" <?php echo in_array($p['id'], $assigned_performers) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($p['name']) . ' (' . htmlspecialchars($p['skill']) . ')'; ?>
                        </option>
                    <?php
    endwhile;
endif; ?>
                </select>
                <small style="color:#6B7280; margin-top:0.25rem; display:block;"><i class="fas fa-mouse-pointer"></i> Hold Ctrl (Windows) or Cmd (Mac) to select multiple.</small>
            </div>
            
            <div class="form-group">
                <label>Assign Animals</label>
                <select name="animals[]" class="form-control" multiple size="6" style="height:auto; min-height:120px; font-size:0.95rem;">
                    <?php if ($animList && $animList->num_rows > 0):
    while ($a = $animList->fetch_assoc()): ?>
                        <option value="<?php echo $a['id']; ?>" <?php echo in_array($a['id'], $assigned_animals) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($a['name']) . ' (' . htmlspecialchars($a['type']) . ')'; ?>
                        </option>
                    <?php
    endwhile;
endif; ?>
                </select>
                <small style="color:#6B7280; margin-top:0.25rem; display:block;"><i class="fas fa-mouse-pointer"></i> Hold Ctrl (Windows) or Cmd (Mac) to select multiple.</small>
            </div>
        </div>

        <button type="submit" class="btn btn-success mt-3" style="font-size:1.1rem; padding:0.5rem 1.5rem;"><i class="fas fa-save"></i> Save Show Setup</button>
    </form>
</div>

<div class="card">
    <div class="card-header flex-between mb-0">
        <h3 style="margin:0;">Scheduled Shows Directory</h3>
        <div class="search-bar">
            <input type="text" id="table-search" class="form-control" placeholder="Search shows...">
        </div>
    </div>
    <div class="table-responsive" style="margin-top: 1rem;">
        <table>
            <thead>
                <tr>
                    <th>Show Name</th>
                    <th>Date & Time</th>
                    <th>Location</th>
                    <th>Duration</th>
                    <th>Ticket Price</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($list && $list->num_rows > 0): ?>
                    <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                        <td>
                            <span class="badge" style="background:var(--card-bg); border:1px solid var(--border-color); padding:0.25rem 0.5rem; border-radius:4px; margin-right: 0.25rem;"><i class="far fa-calendar text-primary"></i> <?php echo date('M d, Y', strtotime($row['show_date'])); ?></span>
                            <span class="badge" style="background:rgba(16,185,129,0.1); color:var(--secondary); padding:0.25rem 0.5rem; border-radius:4px;"><i class="far fa-clock"></i> <?php echo date('h:i A', strtotime($row['show_time'])); ?></span>
                        </td>
                        <td><i class="fas fa-map-marker-alt text-danger"></i> <?php echo htmlspecialchars($row['location']); ?></td>
                        <td><?php echo $row['duration']; ?> min</td>
                        <td style="font-weight:bold; color:var(--secondary);">₹<?php echo number_format($row['price'], 2); ?></td>
                        <td style="text-align: right;">
                            <a href="shows.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary" title="Edit Schedule"><i class="fas fa-edit"></i></a>
                            <a href="shows.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" title="Cancel Show" onclick="return confirm('WARNING: Are you sure you want to cancel and delete this show? All associated assignments will be removed.');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php
    endwhile; ?>
                <?php
else: ?>
                    <tr><td colspan="6" style="text-align:center; padding: 2rem;">No shows scheduled. Create your first show above!</td></tr>
                <?php
endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>

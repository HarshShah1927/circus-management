<?php
require_once '../config/db.php';
require_once 'includes/header.php';

$msg = '';
$edit_mode = false;
$edit_id = 0;
$performer = ['name' => '', 'age' => '', 'skill' => '', 'experience' => '', 'salary' => '', 'image' => ''];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $q = $conn->query("SELECT image FROM performers WHERE id=$id");
    if ($q && $r = $q->fetch_assoc()) {
        if (!empty($r['image']) && file_exists("../uploads/" . $r['image'])) {
            unlink("../uploads/" . $r['image']);
        }
    }
    $conn->query("DELETE FROM performers WHERE id=$id");
    header("Location: performers.php?msg=deleted");
    exit;
}
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted')
    $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Performer deleted successfully.</div>";

// Handle Add / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $age = intval($_POST['age']);
    $skill = $conn->real_escape_string($_POST['skill']);
    $experience = intval($_POST['experience']);
    $salary = floatval($_POST['salary']);
    $image = $_POST['existing_image'] ?? '';

    // File upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $new_name = uniqid('perf_') . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $new_name)) {
                if ($image && file_exists("../uploads/" . $image))
                    unlink("../uploads/" . $image);
                $image = $new_name;
            }
        }
        else {
            $msg = "<div class='alert alert-danger'>Invalid image format. Must be JPG, PNG, GIF, or WebP.</div>";
        }
    }

    if (empty($msg)) {
        if (isset($_POST['id']) && $_POST['id'] > 0) {
            $id = intval($_POST['id']);
            $sql = "UPDATE performers SET name='$name', age=$age, skill='$skill', experience=$experience, salary=$salary, image='$image' WHERE id=$id";
            if ($conn->query($sql)) {
                $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Performer updated successfully.</div>";
            }
            else {
                $msg = "<div class='alert alert-danger'>Database error: " . $conn->error . "</div>";
            }
        }
        else {
            $sql = "INSERT INTO performers (name, age, skill, experience, salary, image) VALUES ('$name', $age, '$skill', $experience, $salary, '$image')";
            if ($conn->query($sql)) {
                $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Performer added successfully.</div>";
            }
            else {
                $msg = "<div class='alert alert-danger'>Database error: " . $conn->error . "</div>";
            }
        }
    }
}

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $q = $conn->query("SELECT * FROM performers WHERE id=$edit_id");
    if ($q && $q->num_rows > 0)
        $performer = $q->fetch_assoc();
}

$list = $conn->query("SELECT * FROM performers ORDER BY id DESC");
?>

<div class="flex-between mb-3">
    <h2><i class="fas fa-users"></i> Manage Performers</h2>
    <?php if ($edit_mode): ?>
        <a href="performers.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Performer</a>
    <?php
endif; ?>
</div>

<?php echo $msg; ?>

<div class="card mb-4" style="border-top: 4px solid var(--primary);">
    <div class="card-header">
        <h3 style="margin:0;"><i class="fas <?php echo $edit_mode ? 'fa-edit' : 'fa-plus-circle'; ?>"></i> <?php echo $edit_mode ? 'Edit Performer' : 'Add New Performer'; ?></h3>
    </div>
    <form method="POST" action="performers.php" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if ($edit_mode): ?>
            <input type="hidden" name="id" value="<?php echo $edit_id; ?>">
            <input type="hidden" name="existing_image" value="<?php echo htmlspecialchars($performer['image']); ?>">
        <?php
endif; ?>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($performer['name']); ?>">
            </div>
            <div class="form-group">
                <label>Age</label>
                <input type="number" name="age" class="form-control" required min="10" max="100" value="<?php echo htmlspecialchars($performer['age']); ?>">
            </div>
            <div class="form-group">
                <label>Primary Skill (e.g. Acrobat)</label>
                <input type="text" name="skill" class="form-control" required value="<?php echo htmlspecialchars($performer['skill']); ?>">
            </div>
            <div class="form-group">
                <label>Experience (Years)</label>
                <input type="number" name="experience" class="form-control" required min="0" value="<?php echo htmlspecialchars($performer['experience']); ?>">
            </div>
            <div class="form-group">
                <label>Salary ($)</label>
                <input type="number" step="0.01" name="salary" class="form-control" required min="0" value="<?php echo htmlspecialchars($performer['salary']); ?>">
            </div>
            <div class="form-group">
                <label>Profile Image</label>
                <input type="file" name="image" class="form-control" accept="image/*">
                <?php if ($edit_mode && $performer['image']): ?>
                    <div class="mt-2">
                        <img src="../uploads/<?php echo $performer['image']; ?>" alt="Preview" style="object-fit:cover; width:80px; height:80px; border-radius:0.5rem; border:1px solid var(--border-color);">
                    </div>
                <?php
endif; ?>
            </div>
        </div>
        <button type="submit" class="btn btn-success mt-3" style="font-size:1.1rem; padding:0.5rem 1.5rem;"><i class="fas fa-save"></i> Save Performer</button>
    </form>
</div>

<div class="card">
    <div class="card-header flex-between mb-0">
        <h3 style="margin:0;">Performers Directory</h3>
        <div class="search-bar">
            <input type="text" id="table-search" class="form-control" placeholder="Search by name, skill...">
            <button type="button" class="btn btn-primary"><i class="fas fa-search"></i></button>
        </div>
    </div>
    <div class="table-responsive" style="margin-top: 1rem;">
        <table>
            <thead>
                <tr>
                    <th style="width: 80px;">Image</th>
                    <th>Name</th>
                    <th>Skill</th>
                    <th>Age</th>
                    <th>Experience</th>
                    <th>Salary</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($list && $list->num_rows > 0): ?>
                    <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php if ($row['image'] && file_exists("../uploads/" . $row['image'])): ?>
                                <img src="../uploads/<?php echo $row['image']; ?>" alt="img" class="image-preview">
                            <?php
        else: ?>
                                <div style="width:50px; height:50px; background:#e5e7eb; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#9ca3af;"><i class="fas fa-user"></i></div>
                            <?php
        endif; ?>
                        </td>
                        <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                        <td><span style="background:rgba(79, 70, 229, 0.1); color:var(--primary); font-weight:bold; padding:0.25rem 0.6rem; border-radius:50px; font-size:0.8rem;"><?php echo htmlspecialchars($row['skill']); ?></span></td>
                        <td><?php echo $row['age']; ?></td>
                        <td><?php echo $row['experience']; ?> years</td>
                        <td>$<?php echo number_format($row['salary'], 2); ?></td>
                        <td style="text-align: right;">
                            <a href="performers.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="performers.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('WARNING: Are you sure you want to delete this performer?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php
    endwhile; ?>
                <?php
else: ?>
                    <tr><td colspan="7" style="text-align:center; padding: 2rem;">No performers registered yet. Add one above!</td></tr>
                <?php
endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

<?php
require_once '../config/db.php';
require_once 'includes/header.php';

$msg = '';
$edit_mode = false;
$edit_id = 0;
// Fields: name, type, age, health_status, trainer, image
$animal = ['name' => '', 'type' => '', 'age' => '', 'health_status' => '', 'trainer' => '', 'image' => ''];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $q = $conn->query("SELECT image FROM animals WHERE id=$id");
    if ($q && $r = $q->fetch_assoc()) {
        if (!empty($r['image']) && file_exists("../uploads/" . $r['image'])) {
            unlink("../uploads/" . $r['image']);
        }
    }
    $conn->query("DELETE FROM animals WHERE id=$id");
    header("Location: animals.php?msg=deleted");
    exit;
}
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted')
    $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Animal deleted successfully.</div>";

// Handle Add / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $type = $conn->real_escape_string($_POST['type']);
    $age = intval($_POST['age']);
    $health_status = $conn->real_escape_string($_POST['health_status']);
    $trainer = $conn->real_escape_string($_POST['trainer']);
    $image = $_POST['existing_image'] ?? '';

    // File upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $new_name = uniqid('anim_') . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $new_name)) {
                if ($image && file_exists("../uploads/" . $image))
                    unlink("../uploads/" . $image);
                $image = $new_name;
            }
        }
        else {
            $msg = "<div class='alert alert-danger'>Invalid image format. Must be JPG, PNG, GIF, or WebP.</div>";
        }
    }

    if (empty($msg)) {
        if (isset($_POST['id']) && $_POST['id'] > 0) {
            $id = intval($_POST['id']);
            $sql = "UPDATE animals SET name='$name', type='$type', age=$age, health_status='$health_status', trainer='$trainer', image='$image' WHERE id=$id";
            if ($conn->query($sql)) {
                $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Animal updated successfully.</div>";
            }
            else {
                $msg = "<div class='alert alert-danger'>Database error: " . $conn->error . "</div>";
            }
        }
        else {
            $sql = "INSERT INTO animals (name, type, age, health_status, trainer, image) VALUES ('$name', '$type', $age, '$health_status', '$trainer', '$image')";
            if ($conn->query($sql)) {
                $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Animal added successfully.</div>";
            }
            else {
                $msg = "<div class='alert alert-danger'>Database error: " . $conn->error . "</div>";
            }
        }
    }
}

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $q = $conn->query("SELECT * FROM animals WHERE id=$edit_id");
    if ($q && $q->num_rows > 0)
        $animal = $q->fetch_assoc();
}

$list = $conn->query("SELECT * FROM animals ORDER BY id DESC");
?>

<div class="flex-between mb-3">
    <h2><i class="fas fa-paw"></i> Manage Animals</h2>
    <?php if ($edit_mode): ?>
        <a href="animals.php" class="btn btn-warning" style="color:#fff;"><i class="fas fa-plus"></i> Add New Animal</a>
    <?php
endif; ?>
</div>

<?php echo $msg; ?>

<div class="card mb-4" style="border-top: 4px solid #F59E0B;">
    <div class="card-header">
        <h3 style="margin:0;"><i class="fas <?php echo $edit_mode ? 'fa-edit' : 'fa-plus-circle'; ?>"></i> <?php echo $edit_mode ? 'Edit Animal' : 'Add New Animal'; ?></h3>
    </div>
    <form method="POST" action="animals.php" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php if ($edit_mode): ?>
            <input type="hidden" name="id" value="<?php echo $edit_id; ?>">
            <input type="hidden" name="existing_image" value="<?php echo htmlspecialchars($animal['image']); ?>">
        <?php
endif; ?>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($animal['name']); ?>">
            </div>
            <div class="form-group">
                <label>Species / Type (e.g. Tiger, Elephant)</label>
                <input type="text" name="type" class="form-control" required value="<?php echo htmlspecialchars($animal['type']); ?>">
            </div>
            <div class="form-group">
                <label>Age (Years)</label>
                <input type="number" name="age" class="form-control" required min="1" max="150" value="<?php echo htmlspecialchars($animal['age']); ?>">
            </div>
            <div class="form-group">
                <label>Health Status</label>
                <select name="health_status" class="form-control" required>
                    <option value="Excellent" <?php echo $animal['health_status'] == 'Excellent' ? 'selected' : ''; ?>>Excellent</option>
                    <option value="Good" <?php echo $animal['health_status'] == 'Good' ? 'selected' : ''; ?>>Good</option>
                    <option value="Needs Attention" <?php echo $animal['health_status'] == 'Needs Attention' ? 'selected' : ''; ?>>Needs Attention</option>
                    <option value="Under Treatment" <?php echo $animal['health_status'] == 'Under Treatment' ? 'selected' : ''; ?>>Under Treatment</option>
                </select>
            </div>
            <div class="form-group">
                <label>Assigned Trainer</label>
                <input type="text" name="trainer" class="form-control" required value="<?php echo htmlspecialchars($animal['trainer']); ?>">
            </div>
            <div class="form-group">
                <label>Animal Picture</label>
                <input type="file" name="image" class="form-control" accept="image/*">
                <?php if ($edit_mode && $animal['image']): ?>
                    <div class="mt-2">
                        <img src="../uploads/<?php echo $animal['image']; ?>" alt="Preview" style="object-fit:cover; width:80px; height:80px; border-radius:0.5rem; border:1px solid var(--border-color);">
                    </div>
                <?php
endif; ?>
            </div>
        </div>
        <button type="submit" class="btn btn-success mt-3" style="font-size:1.1rem; padding:0.5rem 1.5rem; background-color:#F59E0B;"><i class="fas fa-save"></i> Save Animal</button>
    </form>
</div>

<div class="card">
    <div class="card-header flex-between mb-0">
        <h3 style="margin:0;">Registered Animals</h3>
        <div class="search-bar">
            <input type="text" id="table-search" class="form-control" placeholder="Search animals...">
            <button type="button" class="btn btn-warning" style="color:#fff;"><i class="fas fa-search"></i></button>
        </div>
    </div>
    <div class="table-responsive" style="margin-top: 1rem;">
        <table>
            <thead>
                <tr>
                    <th style="width: 80px;">Image</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Age</th>
                    <th>Health Status</th>
                    <th>Trainer</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($list && $list->num_rows > 0): ?>
                    <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php if ($row['image'] && file_exists("../uploads/" . $row['image'])): ?>
                                <img src="../uploads/<?php echo $row['image']; ?>" alt="img" class="image-preview">
                            <?php
        else: ?>
                                <div style="width:50px; height:50px; background:#e5e7eb; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#9ca3af;"><i class="fas fa-paw"></i></div>
                            <?php
        endif; ?>
                        </td>
                        <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                        <td><span style="background:rgba(245, 158, 11, 0.1); color:#F59E0B; font-weight:bold; padding:0.25rem 0.6rem; border-radius:50px; font-size:0.8rem;"><?php echo htmlspecialchars($row['type']); ?></span></td>
                        <td><?php echo $row['age']; ?></td>
                        <td>
                            <?php
        $hs = $row['health_status'];
        $color = $hs == 'Excellent' ? 'var(--secondary)' : ($hs == 'Good' ? '#F59E0B' : 'var(--danger)');
?>
                            <b style="color: <?php echo $color; ?>;"><i class="fas fa-heartbeat"></i> <?php echo $hs; ?></b>
                        </td>
                        <td><?php echo htmlspecialchars($row['trainer']); ?></td>
                        <td style="text-align: right;">
                            <a href="animals.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm" style="background-color:#F59E0B; color:#fff;" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="animals.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('WARNING: Are you sure you want to delete this animal?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php
    endwhile; ?>
                <?php
else: ?>
                    <tr><td colspan="7" style="text-align:center; padding: 2rem;">No animals registered yet. Add one above!</td></tr>
                <?php
endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

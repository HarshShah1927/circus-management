<?php
require_once '../config/db.php';
require_once 'includes/header.php';

// Fetch Statistics
$perfCount = $conn->query("SELECT COUNT(*) as cnt FROM performers")->fetch_assoc()['cnt'];
$animCount = $conn->query("SELECT COUNT(*) as cnt FROM animals")->fetch_assoc()['cnt'];
$showCount = $conn->query("SELECT COUNT(*) as cnt FROM shows")->fetch_assoc()['cnt'];
$revResult = $conn->query("SELECT SUM(total_price) as total FROM tickets")->fetch_assoc()['total'];
$totalRev = $revResult ? $revResult : 0;

// Fetch Monthly Revenue
$monthlyQ = $conn->query("
    SELECT DATE_FORMAT(booking_date, '%b') as month, SUM(total_price) as rev 
    FROM tickets 
    GROUP BY DATE_FORMAT(booking_date, '%Y-%m') 
    ORDER BY booking_date DESC LIMIT 6
");
$months = [];
$revenues = [];

if ($monthlyQ) {
    while ($row = $monthlyQ->fetch_assoc()) {
        $months[] = $row['month'];
        $revenues[] = $row['rev'];
    }
}

// Ensure there is some default data to show if empty
if (empty($months)) {
    $months = [date('M')];
    $revenues = [0];
}
else {
    $months = array_reverse($months);
    $revenues = array_reverse($revenues);
}

// Fetch Latest Bookings
$latestTixQ = $conn->query("SELECT t.*, s.name as show_name FROM tickets t JOIN shows s ON t.show_id = s.id ORDER BY t.booking_date DESC LIMIT 5");
?>

<div class="dashboard-cards">
    <div class="stat-card">
        <div class="stat-icon primary"><i class="fas fa-users"></i></div>
        <div class="stat-details">
            <h3>Performers</h3>
            <p><?php echo $perfCount; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon warning"><i class="fas fa-paw"></i></div>
        <div class="stat-details">
            <h3>Animals</h3>
            <p><?php echo $animCount; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon success"><i class="fas fa-theater-masks"></i></div>
        <div class="stat-details">
            <h3>Upcoming Shows</h3>
            <p><?php echo $showCount; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon danger"><i class="fas fa-dollar-sign"></i></div>
        <div class="stat-details">
            <h3>Total Revenue</h3>
            <p>₹<?php echo number_format($totalRev, 2); ?></p>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
    <!-- Chart -->
    <div class="card">
        <div class="card-header">
            <h2 style="font-size:1.25rem; font-weight:bold;">Revenue Overview</h2>
        </div>
        <canvas id="revenueChart"></canvas>
    </div>

    <!-- Recent Bookings -->
    <div class="card">
        <div class="card-header">
            <h2 style="font-size:1.25rem; font-weight:bold;">Recent Bookings</h2>
        </div>
        <div style="display:flex; flex-direction:column; gap:1rem;">
            <?php if ($latestTixQ && $latestTixQ->num_rows > 0): ?>
                <?php while ($t = $latestTixQ->fetch_assoc()): ?>
                    <div style="padding: 1rem; border: 1px solid var(--border-color); border-radius: 0.5rem; background-color: rgba(0,0,0,0.02);">
                        <div style="font-weight: bold; margin-bottom: 0.25rem;"><?php echo htmlspecialchars($t['customer_name']); ?></div>
                        <div style="font-size: 0.875rem; color: #6B7280; display:flex; justify-content:space-between;">
                            <span><?php echo htmlspecialchars($t['show_name']); ?></span>
                            <span style="color:var(--secondary); font-weight:bold;">+₹<?php echo number_format($t['total_price'], 2); ?></span>
                        </div>
                    </div>
                <?php
    endwhile; ?>
            <?php
else: ?>
                <div class="alert alert-warning" style="margin: 0; padding:1rem;">No recent bookings available.</div>
            <?php
endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var ctx = document.getElementById('revenueChart').getContext('2d');
    var isDark = document.body.getAttribute('data-theme') === 'dark';
    var textColor = isDark ? '#fff' : '#333';
    var gridColor = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';

    var revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($months); ?>,
            datasets: [{
                label: 'Revenue (₹)',
                data: <?php echo json_encode($revenues); ?>,
                backgroundColor: 'rgba(79, 70, 229, 0.2)',
                borderColor: 'rgba(79, 70, 229, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true, grid: { color: gridColor }, ticks: { color: textColor } },
                x: { grid: { color: gridColor }, ticks: { color: textColor } }
            },
            plugins: {
                legend: { labels: { color: textColor } }
            }
        }
    });

    // Make chart globally updatable for theme toggle
    window.updateChartsTheme = function() {
        var isDarkNow = document.body.getAttribute('data-theme') === 'dark';
        revenueChart.options.scales.y.ticks.color = isDarkNow ? '#fff' : '#333';
        revenueChart.options.scales.x.ticks.color = isDarkNow ? '#fff' : '#333';
        revenueChart.options.scales.y.grid.color = isDarkNow ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
        revenueChart.options.scales.x.grid.color = isDarkNow ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
        revenueChart.options.plugins.legend.labels.color = isDarkNow ? '#fff' : '#333';
        revenueChart.update();
    };
});
</script>

<?php require_once 'includes/footer.php'; ?>

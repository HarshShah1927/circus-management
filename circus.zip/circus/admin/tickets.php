<?php
require_once '../config/db.php';
require_once 'includes/header.php';

$msg = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM tickets WHERE id=$id");
    header("Location: tickets.php?msg=deleted");
    exit;
}
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Ticket record deleted successfully.</div>";
}

// Fetch total stats
$totalTicketsQuery = $conn->query("SELECT SUM(seats) as cnt FROM tickets");
$totalTickets = $totalTicketsQuery ? $totalTicketsQuery->fetch_assoc()['cnt'] : 0;
if (!$totalTickets)
    $totalTickets = 0;

$totalRevenueQuery = $conn->query("SELECT SUM(total_price) as rev FROM tickets");
$totalRevenue = $totalRevenueQuery ? $totalRevenueQuery->fetch_assoc()['rev'] : 0;
if (!$totalRevenue)
    $totalRevenue = 0;

// Fetch ticket list
$sql = "
    SELECT t.*, s.name as show_name, s.show_date, s.show_time 
    FROM tickets t 
    JOIN shows s ON t.show_id = s.id 
    ORDER BY t.booking_date DESC
";
$list = $conn->query($sql);
?>

<div class="flex-between mb-3">
    <h2><i class="fas fa-ticket-alt"></i> Manage Tickets</h2>
</div>

<?php echo $msg; ?>

<div class="dashboard-cards mb-4">
    <div class="stat-card">
        <div class="stat-icon primary"><i class="fas fa-ticket-alt"></i></div>
        <div class="stat-details">
            <h3>Total Seats Booked</h3>
            <p><?php echo $totalTickets; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon success"><i class="fas fa-dollar-sign"></i></div>
        <div class="stat-details">
            <h3>Total Ticket Revenue</h3>
            <p>₹<?php echo number_format($totalRevenue, 2); ?></p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header flex-between mb-0">
        <h3 style="margin:0;">Recent Bookings Directory</h3>
        <div class="search-bar">
            <input type="text" id="table-search" class="form-control" placeholder="Search tickets...">
        </div>
    </div>
    <div class="table-responsive" style="margin-top: 1rem;">
        <table>
            <thead>
                <tr>
                    <th>Ticket ID</th>
                    <th>Customer Name</th>
                    <th>Show</th>
                    <th>Seats</th>
                    <th>Total Price</th>
                    <th>Booking Date</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($list && $list->num_rows > 0): ?>
                    <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($row['ticket_unique_id']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td>
                            <div><strong><?php echo htmlspecialchars($row['show_name']); ?></strong></div>
                            <div style="font-size: 0.85rem; color:#6B7280;">
                                <?php echo date('M d, Y', strtotime($row['show_date'])); ?> &bull; 
                                <?php echo date('h:i A', strtotime($row['show_time'])); ?>
                            </div>
                        </td>
                        <td><span class="badge" style="background:rgba(79,70,229,0.1); color:var(--primary);"><?php echo $row['seats']; ?></span></td>
                        <td style="font-weight:bold; color:var(--secondary);">₹<?php echo number_format($row['total_price'], 2); ?></td>
                        <td><?php echo date('M d, Y h:i A', strtotime($row['booking_date'])); ?></td>
                        <td style="text-align: right;">
                            <a href="tickets.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" title="Delete Booking" onclick="return confirm('WARNING: Are you sure you want to delete this ticket record? This action cannot be undone.');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php
    endwhile; ?>
                <?php
else: ?>
                    <tr><td colspan="7" style="text-align:center; padding: 2rem;">No tickets booked yet.</td></tr>
                <?php
endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

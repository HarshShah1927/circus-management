<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Circus Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button id="mobile-menu-btn" class="btn btn-primary" style="display:none; margin-right: 1rem;"><i class="fas fa-bars"></i></button>
                <strong>Circus Management System</strong>
            </div>
            <div class="topbar-right">
                <button id="theme-toggle" class="theme-switch" title="Toggle Dark Mode"></button>
                <div class="user-profile" style="display: flex; align-items: center;">
                    <i class="fas fa-user-circle" style="font-size: 1.5rem; color: var(--primary);"></i>
                    <span style="font-weight: 500; margin-left: 0.5rem;"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                </div>
            </div>
        </header>
        <div class="content-wrapper">

<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <i class="fas fa-campground" style="margin-right: 0.75rem; color: var(--secondary);"></i>
        Grand Circus
    </div>
    <ul class="sidebar-menu" style="display:flex; flex-direction:column; height: 100%;">
        <li><a href="index.php" class="<?php echo($current_page == 'index.php') ? 'active' : ''; ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="performers.php" class="<?php echo($current_page == 'performers.php') ? 'active' : ''; ?>"><i class="fas fa-users"></i> Performers</a></li>
        <li><a href="animals.php" class="<?php echo($current_page == 'animals.php') ? 'active' : ''; ?>"><i class="fas fa-paw"></i> Animals</a></li>
        <li><a href="shows.php" class="<?php echo($current_page == 'shows.php') ? 'active' : ''; ?>"><i class="fas fa-theater-masks"></i> Shows</a></li>
        <li><a href="tickets.php" class="<?php echo($current_page == 'tickets.php') ? 'active' : ''; ?>"><i class="fas fa-ticket-alt"></i> Tickets & Revenue</a></li>
        
        <li style="margin-top: 1rem; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1rem;">
            <a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> Public Site</a>
        </li>
        <li style="margin-top: auto;">
            <a href="logout.php" style="color: var(--danger);"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </li>
    </ul>
</aside>
